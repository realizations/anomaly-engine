# Security

Please do not post a live exploit in a public issue. Report security problems privately through the repository's security contact once one is configured.

## Security boundaries
- world packages are untrusted data
- remote event feeds are untrusted data
- native commands are never allowed from remote world data
- external URLs use explicit allow/deny rules
- downloaded updates must be verified before execution

## Threats to consider
- archive traversal
- malicious world assets
- malformed JSON
- oversized textures
- remote-feed abuse
- command execution attempts
- unsafe updater packages
