# Roadmap

## 0.1 — Vertical slice
- [ ] Native Windows host
- [ ] WebView2 surface behind desktop
- [ ] First world scene
- [ ] Clock-driven lighting
- [ ] Event bus
- [ ] Rare event scheduler
- [ ] Tray pause/resume

## 0.2 — Living world
- [ ] Local persistence (SQLite)
- [ ] More anomalies
- [ ] Journal/discoveries
- [ ] Multi-monitor
- [ ] Fullscreen detection
- [ ] Quality presets

## 0.3 — Real-world signals
- [ ] Weather adapter
- [ ] Astronomy adapter
- [ ] Network state adapter
- [ ] Optional GitHub adapter

## 0.4 — World format
- [ ] World manifest schema
- [ ] Import/export
- [ ] Validation command
- [ ] Example creator world
- [ ] World authoring guide

## 0.5 — Community
- [ ] World submission process
- [ ] Event packs
- [ ] Remote event feed
- [ ] Signed release artifacts

## 1.0 — Public release
- [ ] Installer
- [ ] Crash recovery
- [ ] Documentation complete
- [ ] CI build + tests
- [ ] Release automation
- [ ] Accessibility pass
- [ ] Measured performance report
