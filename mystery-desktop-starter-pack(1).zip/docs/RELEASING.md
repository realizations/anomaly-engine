# Releasing

## Pre-release checklist
- [ ] clean working tree
- [ ] tests pass
- [ ] release build works on a clean Windows environment
- [ ] WebView2 availability is checked
- [ ] package contents audited
- [ ] third-party notices updated
- [ ] changelog updated
- [ ] checksums generated
- [ ] GitHub release notes written

## Release channels
- nightly/development
- beta
- stable

Do not auto-run unsigned update packages.
