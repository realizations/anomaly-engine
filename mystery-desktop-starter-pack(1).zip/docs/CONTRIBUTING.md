# Contributing

## Good first contributions
- documentation fixes
- event definitions
- small visual scenes
- accessibility improvements
- performance profiling
- bug fixes

## Before opening a PR
- build locally
- run tests
- describe the user-facing effect
- keep commits focused
- avoid unrelated formatting changes

## World contributions
Worlds should include a valid manifest, original/properly licensed assets, and no arbitrary native code.

## Commit style
Use focused messages such as:

```text
feat: add event scheduler
fix: recover webview after navigation failure
docs: explain world manifest
```
