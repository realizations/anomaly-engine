# Project Brief

## Working name
Mystery Desktop

## One sentence
An open-source live mystery that lives behind your desktop icons.

## The idea
Turn the feeling of a strange interactive website into a persistent desktop world. The first world is a retro computer/observatory environment that quietly changes over time, remembers local discoveries, and occasionally produces rare anomalies.

## What makes it different
The wallpaper is not the product by itself. The product is the *world state*: scenes, events, secrets, persistence, and a creator-friendly format that lets other people make worlds.

## IP direction
The project may take inspiration from mystery-web aesthetics and the idea of hidden fictional computer interfaces, but all shipped story, artwork, sound, characters, names, and code should be original or properly licensed. Do not ship third-party copyrighted franchise assets.

## MVP
1. Windows wallpaper host.
2. WebView2-rendered local world.
3. One animated scene.
4. Local clock + day/night state.
5. Event bus with one rare anomaly.
6. Tray controls.
7. Persistent local discovery state.

## North star
The best moment is when the user looks at their desktop and realizes that something changed while they were away.
