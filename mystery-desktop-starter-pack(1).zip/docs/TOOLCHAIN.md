# Toolchain

## Recommended stack

### Development
- Windows 10/11
- Visual Studio 2026
- .NET 10 (LTS)
- WPF
- WebView2
- Node.js + Vite + TypeScript
- Git
- GitHub

### Design
- Figma for UI/flows
- Pencil or Figma for quick interface iteration
- Aseprite for pixel/retro animation when needed
- Blender for optional 3D elements
- Audacity for audio editing

### Workflow
1. Design the world/scene.
2. Build the browser version first.
3. Run it with Vite hot reload.
4. Embed the built world in WebView2.
5. Add Windows integration only after the scene works.
6. Commit each milestone separately.

## Why these choices
.NET 10 is the currently supported LTS release. Microsoft documents WebView2 integration for Windows desktop applications, including WPF, and Vite provides a fast dev server with hot module replacement.

## Optional alternatives
Godot is a valid alternative if the project becomes predominantly game-like. For this particular project, the web-first world format is intentionally easier for contributors who already know HTML/CSS/TypeScript.
