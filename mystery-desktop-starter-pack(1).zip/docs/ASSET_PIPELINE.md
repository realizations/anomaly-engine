# Asset Pipeline

## Visual language
- cozy nocturnal rooms
- CRT phosphor glow
- hand-drawn symbols
- forest silhouettes
- restrained teal/green + warm amber + muted red
- grain and scanlines used sparingly

## Asset classes
- background: 1920×1080 minimum for the first release
- hero/preview: 1280×640 or larger
- icon: SVG + PNG fallbacks
- UI symbols: SVG where practical
- audio: original or properly licensed

## Source-of-truth
Keep editable masters outside the shipped build. Commit optimized export assets to the repository. Keep an attribution record for third-party material.

## Current starter assets
See `assets/concept`, `assets/branding`, and `demo`.
