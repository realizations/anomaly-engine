# Privacy

Privacy is a design constraint.

## Default
- no account required
- no analytics required
- no ad network
- no uploaded screenshots
- no collection of personal files
- local discovery history only

Optional integrations should be opt-in and clearly described. Public-data integrations should use caching and sensible request intervals.

The application must never pretend that a local event is the result of surveillance.
