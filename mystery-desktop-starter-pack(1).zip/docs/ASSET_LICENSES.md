# Asset Licenses

All shipped visual/audio assets should be either:

1. created for this project,
2. public domain, or
3. licensed for redistribution under terms compatible with this repository.

For each third-party asset, record:

```text
Asset:
Author:
Source:
License:
URL:
Modifications:
Attribution required:
```

Do not ship recognizable franchise artwork, logos, screenshots, music, or extracted website assets without permission.
