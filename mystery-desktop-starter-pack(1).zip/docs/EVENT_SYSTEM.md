# Event System

## Event shape

```json
{
  "id": "evt_01",
  "type": "time.midnight",
  "source": "clock",
  "timestamp": "2026-09-27T22:00:00Z",
  "priority": 5,
  "rarity": "common",
  "durationMs": 0,
  "payload": {}
}
```

## Initial event families
- `time.*`
- `system.*`
- `network.*`
- `world.*`
- `anomaly.*`
- `user.*`
- `integration.*`

## Rarity
- common
- uncommon
- rare
- very_rare
- legendary

Rarity is a scheduling constraint, not a promise that an event occurs on a specific date. Use cooldowns and recent-event history to prevent repetition.

## Safety
Remote events must be data only. They may select registered effects, but must never execute arbitrary native code, shell commands, installers, or downloaded scripts with host privileges.
