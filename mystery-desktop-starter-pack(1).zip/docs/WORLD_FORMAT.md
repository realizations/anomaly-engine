# World Format

```text
world/
├── manifest.json
├── scenes/
├── assets/
├── audio/
├── events/
├── lore/
└── thumbnails/
```

## Manifest

```json
{
  "id": "nightwatch",
  "name": "Nightwatch",
  "version": "0.1.0",
  "engine": ">=0.1.0",
  "author": "Ali S.",
  "entry": "index.html"
}
```

## Constraints
- Paths are relative to the world package.
- Packages must be validated before installation.
- No executable binaries inside ordinary world packages.
- Avoid arbitrary network requests from worlds.
- Cap package size and asset dimensions.
