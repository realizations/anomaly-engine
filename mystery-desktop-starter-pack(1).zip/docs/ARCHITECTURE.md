# Architecture

## Core split

```text
Windows host (.NET)
        │
        ├── desktop/window management
        ├── tray + startup
        ├── monitor/power/fullscreen state
        ├── persistence
        │
        └── WebView2
              │
              └── world runtime (TypeScript/Vite)
                    ├── renderer
                    ├── scene system
                    ├── event bus
                    ├── scheduler
                    ├── entity system
                    └── world API
```

## Rule
External data sources should publish normalized events. Rendering code should consume events rather than calling APIs directly.

## Why this stack
C#/.NET gives direct Windows integration; WebView2 lets the visual layer stay in web technologies; Vite keeps iteration fast during development.

## First implementation
Start with WPF + WebView2 because Microsoft documents a straightforward WPF integration path and the host needs Win32 interop for desktop-window behavior. Move to other Windows UI technology only when there is a concrete reason.
