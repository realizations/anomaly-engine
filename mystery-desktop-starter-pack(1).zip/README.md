# Mystery Desktop

> **Your desktop has a secret.**

An open-source live mystery that lives behind your desktop icons.

![Project preview](assets/branding/github-social-preview.png)

## What is this?

Mystery Desktop turns the familiar live-wallpaper idea into a persistent interactive world. The wallpaper runs quietly behind the desktop, changes with time, remembers discoveries locally, and can produce rare events you may or may not catch.

The first reference world is a small retro observatory/computer environment: cozy, strange, and occasionally unsettling.

## Core idea

```text
Desktop
  ↓
Native Windows host
  ↓
WebView2
  ↓
Living world
  ↓
Events → scenes → anomalies → memory
```

## Features planned

- Live Windows wallpaper
- Interactive CRT-style world
- Time/day/night changes
- Rare anomalies
- Local discovery journal
- Multi-monitor support
- Optional real-world event sources
- Moddable world format
- Open-source creator workflow

## Current status

The repository starts with the project specification, architecture, asset kit, and a dependency-free browser demo. The native wallpaper host is the first implementation milestone.

## Run the visual demo

Open `demo/index.html` directly in a browser, or serve the repository with any local static server. The demo intentionally has no external dependencies.

## Recommended build stack

- C# / .NET 10
- WPF + WebView2
- TypeScript + Vite
- SQLite for local persistence
- GitHub Actions for CI

## Repository map

```text
docs/          project specs and engineering docs
assets/        concept + branding assets
demo/          browser-first prototype
worlds/        world packages
.github/       CI + issue templates
```

## Design principle

The normal state should be quiet. The unusual state should feel worth noticing.

If the wallpaper is always screaming for attention, the mystery disappears.

## IP note

This is an original open-source project inspired by the broader aesthetic of mysterious web experiences and fictional computer interfaces. It is not affiliated with any existing franchise. Do not contribute or redistribute copyrighted franchise material.

## License

MIT. See `LICENSE`.

## Author

Ali S. · GitHub: [@realizations](https://github.com/realizations)
