---
name: World submission
about: Propose or submit a community world
---

## World name

## Description

## Assets
Confirm that all included assets are original or properly licensed.

## Requirements
Engine version:
Package size:

## Screenshots
