---
name: Bug report
about: Report a reproducible problem
---

## What happened?

## Expected behavior

## Steps to reproduce

## Environment
- Windows version:
- App version:
- World:
- GPU:
- Monitor setup:

## Logs
Paste relevant logs, removing secrets first.
